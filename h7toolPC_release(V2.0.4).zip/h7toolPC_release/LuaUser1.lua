beep()
print("123")