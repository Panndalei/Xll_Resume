-------------------------------------------------------
-- 文件名 : nRF52_Lib.lua
-- 版  本 : V1.0  2021-04-06
-- 说  明 : 安富莱电子
-------------------------------------------------------

--没有UID，固定返回0

--复位期间执行的函数. 目的:debug期间冻结看门狗时钟,低功耗模式启动HCLK和FCLK
function InitUnderReset(void)
	local str = "error"
	local RCC_APB1ENR_M3M0_M3N4 =  0x4002101C
	
	print("InitUnderReset() -- none")

	--403A 407系列缺省没有开PWR标志位
	-- if (pg_write32(RCC_APB1ENR_M3M0_M3N4, 0x10000000) == 0) then
		-- goto quit_err
	-- end
	
	-- if (pg_write32(0xE0042004, 0x00000307) == 0) then
		-- goto quit_err
	-- end

	-- if (ReadDeviceID() ~= 0) then
		-- goto quit_err
	-- end

::quit_ok::
	str = "OK"

::quit_err::
	print(str)

	return str
end

--读芯片ID
function ReadDeviceID(void)
	local str
	local err = 0
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end
	
	g_DevID = {pg_read32(0x40015800)} --全局变量g_DevID[]

	str = "..DeviceID = "
	for j = 1, ch_num, 1 do
		str = str..string.format("%08X ", g_DevID[j])
		if (g_DevID[j] == 0) then
			err = 1
		end
	end

	print(str)
	return err
end

--DP AP寄存器定义
function SWD_RegDefine(void)
	--Debug Port Register Addresses
	DP_IDCODE 	= 0x00	--IDCODE Register (SW Read only)
	DP_ABORT		= 0x00	--Abort Register (SW Write only)
	DP_CTRL_STAT= 0x04	--Control & Status
	DP_WCR    	= 0x04	--Wire Control Register (SW Only)
	DP_SELECT 	= 0x08	--Select Register (JTAG R/W & SW W)
	DP_RESEND 	= 0x08	--Resend (SW Read Only)
	DP_RDBUFF 	= 0x0C	--Read Buffer (Read Only)

	--Debug Select Register definitions
	-- #define CTRLSEL        0x00000001  // CTRLSEL (SW Only)
	-- #define APBANKSEL      0x000000F0  // APBANKSEL Mask
	-- #define APSEL          0xFF000000  // APSEL Mask

	--Access Port Register Addresses
	AP_CSW = 0x00	--Control and Status Word
	AP_TAR = 0x04	--Transfer Address	
	AP_8	 = 0X08	
	AP_DRW = 0x0C	--Data Read/Write
	AP_BD0 = 0x10	--Banked Data 0
	AP_BD1 = 0x14	--Banked Data 1
	AP_BD2 = 0x18	--Banked Data 2
	AP_BD3 = 0x1C	--Banked Data 3
	AP_ROM = 0xF8	--Debug ROM Address
	AP_IDR = 0xFC	--Identification Register
end

--芯片专有的解除保护函数, CTRL-AP
function MCU_RemoveProtect(void)
	local i
	local val = {}	
	local j
	local ch_num

	if (MULTI_MODE == 0) then
		ch_num = 1
	else
		ch_num = MULTI_MODE
	end	
	
	SWD_RegDefine()
	
	pg_swd("WDP", DP_SELECT, 0x01000000)
	pg_swd("WAP", AP_CSW, 0x00000001)
	pg_swd("RAP", AP_CSW)			

	pg_swd("WAP", AP_CSW, 0x00000000)
	pg_swd("RAP", AP_CSW)	

	pg_swd("WAP", AP_TAR, 0x00000001)
	
	delayms(50)	

	--等待AP8的值由1变为0
	for i = 0, 200, 1 do
		local err
		
		val = {pg_swd("RAP", AP_8)}
		err = 0
		for j = 1, ch_num, 1 do
			if (val[j] ~= 0) then
				err = 1
			end
		end
		delayms(5)
		if (err == 0) then
			break
		end
	end	
	
	--全局变量，解除读保护后，无需写入缺省OB, 全FF
	IGNORE_WRITE_OB_SECURE_OFF = 1
end

--芯片专有的整片擦除
-- function MCU_EraseMass(void)
	-- MCU_RemoveProtect()
	-- return "OK"
-- end



---------------------------结束-----------------------------------
